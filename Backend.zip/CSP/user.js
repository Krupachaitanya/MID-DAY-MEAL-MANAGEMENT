const express = require('express');
const mysql = require("mysql");
const bodyParser = require("body-parser");
const path = require('path');
const util = require('util');
const cors = require('cors');
const router = express.Router();
const connection = require('./connection');


const app = express();



// Use CORS middleware
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*"); // Update to the domain you want to allow
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    next();
  });

  



const query = util.promisify(connection.query).bind(connection);



// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use("/assets", express.static("assets"));


// Get all registrations
router.get('/registration', (req, res) => {
    const query = "SELECT * FROM registration";
    connection.query(query, (err, results) => {
        if (!err) {
            return res.status(200).json(results);
        } else {
            return res.status(500).json(err);
        }
    });
});

// Delete a registration by username
router.delete('/registration/:username', (req, res) => {
    const username = req.params.username;
    const query = "DELETE FROM registration WHERE username = ?";
    connection.query(query, [username], (err, results) => {
        if (err) {
            console.error('Error deleting registration:', err);
            return res.status(500).json({ message: 'Server error' });
        }
        if (results.affectedRows === 0) {
            return res.status(404).json({ message: 'User not found' });
        }
        res.status(200).json({ message: 'Registration deleted successfully' });
    });
});





// Update a registration by username
router.patch('/registration/:username', (req, res) => {
  const username = req.params.username;
  const { email, password } = req.body;
  const query = "UPDATE registration SET email = ?, password = ? WHERE username = ?";
  connection.query(query, [email, password, username], (err, results) => {
      if (err) {
          console.error('Error updating registration:', err);
          return res.status(500).json({ error: err.message });
      }
      if (results.affectedRows === 0) {
          return res.status(404).json({ message: "User not found" });
      }
      res.status(200).json({ message: "User updated successfully" });
  });
});
// Register a new user
router.post('/registration', (req, res) => {
  const { username, email, password } = req.body;
  
  // Check if username already exists
  const checkQuery = "SELECT * FROM registration WHERE username = ?";
  connection.query(checkQuery, [username], (err, results) => {
      if (err) {
          console.error('Error checking username:', err);
          return res.status(500).send('Server error');
      }
      if (results.length > 0) {
          return res.status(400).json({ message: 'Username already taken' });
      }
      
      // Insert new user if username is unique
      const insertQuery = "INSERT INTO registration (username, email, password) VALUES (?, ?, ?)";
      connection.query(insertQuery, [username, email, password], (err) => {
          if (err) {
              console.error('Error registering user:', err);
              return res.status(500).send('Error registering user');
          }
          console.log('User registered successfully');
          return res.status(200).json({ message: 'User registered successfully' });
      });
  });
});

// Register a new user
router.post('/register', (req, res) => {
    const { username, password, email } = req.body;
    const query = "INSERT INTO registration (username, password, email) VALUES (?, ?, ?)";
    connection.query(query, [username, password, email], (err) => {
      if (err) {
        console.error('Error registering user: ', err);
        return res.status(500).send('Error registering user');
      } else {
        console.log('User registered successfully');
        return res.status(200).send('User registered successfully');
      }
    });
  })

// Define routes
app.post('/user/login', (req, res) => {
    const { email, password } = req.body;

    const query = "SELECT * FROM registration WHERE email = ? AND password = ?";
    connection.query(query, [email, password], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Error logging in user' });
        }
        if (results.length > 0) {
            return res.status(200).json({ message: 'Welcome! Login successful.' });
        } else {
            return res.status(401).json({ message: 'Invalid email or password' });
        }
    });
});


// Serve static files or a simple HTML page
app.get("/", function(req, res) {
    res.send('<h1>Welcome to the Server</h1>');
});

// Start the server
const PORT = 8081;
app.listen(PORT, () => {
    console.log('Server running on port ${PORT}');
});

app.options('*', cors()); // Handle preflight requests


module.exports = router;